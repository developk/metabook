package com.rent.model;

public class ExistBook {
	
	private String book_No;
	private int quantity;
	private String pur_Date;
	
	ExistBook() {
		
	}
	
	ExistBook(String bno, int quantity, String purdate) {
		book_No = bno;
		this.quantity = quantity;
		pur_Date = purdate;
	}

	String getBook_No() {
		return book_No;
	}

	void setBook_No(String book_No) {
		this.book_No = book_No;
	}

	int getQuantity() {
		return quantity;
	}

	void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	String getPur_Date() {
		return pur_Date;
	}

	void setPur_Date(String pur_Date) {
		this.pur_Date = pur_Date;
	}
	
}
