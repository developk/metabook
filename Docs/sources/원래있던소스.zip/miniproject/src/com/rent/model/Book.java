package com.rent.model;
/**
 * @author Developk
 */

class Book {
	
	private String book_No;
	private String book_Name;
	private String isbn;
	private String writer;
	private String publisher;
	private String pub_Date;
	private int cost;
	
	
	Book() {
		
	}
	
	Book(String no, String name, String isbn, String writer, String pub, String date, int cost) {
		book_No = no;
		book_Name = name;
		this.isbn = isbn;
		this.writer = writer;
		publisher = pub;
		pub_Date = date;
		this.cost = cost;
	}
	
	void setNo(String no) {
		book_No = no;
	}
	
	String getNo() {
		return book_No;
	}
	
	void setName(String name) {
		book_Name = name;
	}
	
	String getName() {
		return book_Name;
	}
	
	void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	
	String getIsbn() {
		return isbn;
	}
	
	void setWriter(String writer) {
		this.writer = writer;
	}
	
	String getWriter() {
		return writer;
	}
	
	void setPub(String pub) {
		publisher = pub;
	}
	
	String getPub() {
		return publisher;
	}
	
	void setPubDate(String date) {
		pub_Date = date;
	}
	
	String getPubDate() {
		return pub_Date;
	}
	
	void setCost(int cost) {
		this.cost = cost;
	}
	
	int getCost() {
		return cost;
	}
	
}
