package com.rent.model;

/**
 * @author Developk
 */

public class Customer {
	
	private String cust_Id;
	private String cust_Pw;
	private String cust_Name;
	private String cust_Jumin;
	private String cust_Email;
	private String Address;
	private String Phone;
	private int Chk_Admin;
	
	public Customer() {
		
	}
	
	public Customer(String id, String pw, String name, String jumin, String email, String addr, String phone, int chkadmin) {
		cust_Id = id;
		cust_Pw = pw;
		cust_Name = name;
		cust_Jumin = jumin;
		cust_Email = email;
		Address = addr;
		Phone = phone;
		Chk_Admin =chkadmin; 
	}

	public String getId() {
		return cust_Id;
	}

	public void setId(String id) {
		cust_Id = id;
	}
	
	public String getPw() {
		return cust_Pw;
	}
	
	public void setPw(String pw) {
		cust_Pw = pw;
	}
	
	public String getName() {
		return cust_Name;
	}
	
	public void setName(String name) {
		cust_Name = name;
	}
	
	public String getJumin() {
		return cust_Jumin;
	}
	public void setJumin(String jumin) {
		cust_Jumin = jumin;
	}
	
	
	public String getEmail() {
		return cust_Email;
	}
	
	public void setEmail(String email) {
		cust_Email = email;
	}
	
	public void setAddr(String addr) {
		Address = addr;
	}
	
	public String getAddr() {
		return Address;
	}
	
	public void setPhone(String phone) {
		Phone = phone;
	}
	
	public String getPhone() {
		return Phone;
	}
	
	public int getChkAdmin() {
		return Chk_Admin;
	}
	
}
