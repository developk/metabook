package com.rent.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.rent.controller.DbConnection;

public class regCustomer {
	
	private static DbConnection conn = null; 
	
	public void addCust(Customer customer) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
			con = conn.getConnection();
			String sql1 = "insert into customer" 
					+ "(Cust_ID, Cust_PW, Cust_Name, Cust_Jumin, Cust_Email, Address, Phone, Chk_Admin)"
					+ "values (?, ?, ?, ?, ?, ?, ?, 0)";
			try {
				pstmt = con.prepareStatement(sql1);
				pstmt.executeUpdate();
				
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			
		
	}

}
