package com.rent.model;


public class RentalDetail {
	
	private String rentalNo;
	private String cust_Id;
	private String book_No;
	private int rentalCost;
	private String rentaldate;
	private String expectdate;
	private String returndate;
	private int quantity;
	
	RentalDetail() {
		
	}
	
	RentalDetail(String rNo, String cid, String bid, int renCo, 
			String rendate, String exdate, String redate, int quantity) {
		rentalNo = rNo;
		cust_Id = cid;
		book_No = bid;
		rentalCost = renCo;
		rentaldate = rendate;
		expectdate = exdate;
		returndate = redate;
		this.quantity= quantity;  
	}

	String getRentalNo() {
		return rentalNo;
	}

	void setRentalNo(String rentalNo) {
		this.rentalNo = rentalNo;
	}

	String getCustID() {
		return cust_Id;
	}

	void setCustID(String custID) {
		this.cust_Id = custID;
	}

	String getBookID() {
		return book_No;
	}

	void setBookID(String bookID) {
		this.book_No = bookID;
	}

	int getRentalCost() {
		return rentalCost;
	}

	void setRentalCost(int rentalCost) {
		this.rentalCost = rentalCost;
	}

	String getRentaldate() {
		return rentaldate;
	}

	void setRentaldate(String rentaldate) {
		this.rentaldate = rentaldate;
	}

	String getExpectdate() {
		return expectdate;
	}

	void setExpectdate(String expectdate) {
		this.expectdate = expectdate;
	}

	String getReturndate() {
		return returndate;
	}

	void setReturndate(String returndate) {
		this.returndate = returndate;
	}

	int getQuantity() {
		return quantity;
	}

	void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
