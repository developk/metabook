package com.rent.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//import com.kboard.bean.db.BoardConnection;

public class DbConnection {

	Connection con = null; // �������̽� connetion �� �����ϴ� getConnection()���

	private static DbConnection instance;

	public static DbConnection getInstance() {
		if (instance == null) {
			instance = new DbConnection();
		}
		return instance;
	}

	public DbConnection() {

		dbConn();

	}

	public boolean dbConn() { // database ���ἳ��

		try {

			String driver = "com.mysql.jdbc.Driver";
			String url = "jdbc:mysql://localhost:3306/book";
			String user = "root";
			String pass = "0000";

			Class.forName(driver);
			con = DriverManager.getConnection(url, user, pass);

			return true;

		} catch (SQLException e) {
			e.printStackTrace();
			return false;

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;

		} catch (Exception e) {
			e.printStackTrace();
			return false;

		}
	}

	public void dbClose() {
		try {
			con.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public Connection getConnection() {

		return con;
	}

}
