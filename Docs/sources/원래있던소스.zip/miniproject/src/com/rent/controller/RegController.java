package com.rent.controller;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.rent.model.Customer;
public class RegController {
	
	private static RegController instance;
	public static RegController getInstance() {
		if (instance == null) {
			instance = new RegController();
		}
		return instance;
	}
	
	
	public boolean addCust(Customer cust) {
		boolean flag = false;
		PreparedStatement pstmt = null;
		DbConnection dbCon = DbConnection.getInstance();
		String sql = "insert into client values(?,?,?,?,?,?,?,0)";
		
		try {
			pstmt = dbCon.getConnection().prepareStatement(sql);
			
			pstmt.setString(1, cust.getId());
			pstmt.setString(2, cust.getPw());
			pstmt.setString(3, cust.getName());
			pstmt.setString(4, cust.getJumin());
			pstmt.setString(5, cust.getEmail());
			pstmt.setString(6, cust.getAddr());
			pstmt.setString(7, cust.getPhone());
			pstmt.setInt(8, cust.getChkAdmin());
			
			flag = true;
			
		} catch (SQLException e) {
			flag = false;
			e.printStackTrace();
		}
		return flag;
	}

}
