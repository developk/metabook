package com.rent.controller;

import java.sql.*;

class OraConn {

	public static void main(String[] args) {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("driver loading");
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "kim", "0000");
			
			System.out.println("success");
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("ClassNotFoundException" + e);
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("SQLException" + e);
		}
		
	} // end main
} // end class